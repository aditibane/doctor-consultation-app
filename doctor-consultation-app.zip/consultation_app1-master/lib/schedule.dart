class Schedule {
  final String name;
  final String date;
  final String month;
  final String day;
  final String time;
  Schedule({this.name, this.date, this.day, this.month, this.time});
}
